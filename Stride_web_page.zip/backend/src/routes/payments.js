import express from "express";
import { v4 as uuid } from "uuid";
import db from "../lib/db.js";
import { getClient } from "../lib/opClient.js";

const router = express.Router();

/**
 * STEP 1: User wants to send money.
 * Body: { userId, receiverWalletAddress, amount } amount = e.g. "5.00" (we convert to minor units)
 *
 * Flow per Open Payments spec:
 *  a) Resolve sender + receiver wallet addresses
 *  b) Request a grant to create an "incoming payment" on the RECEIVER's wallet
 *  c) Create the incoming payment (this is what the sender will pay into)
 *  d) Request a grant to create a "quote" on the SENDER's wallet, create the quote
 *  e) Request a grant for "outgoing payment" on sender's wallet -> this is the one
 *     that requires interactive user approval (redirect to wallet provider)
 *  f) Return the redirect URL to the frontend so the user can approve in their wallet
 */
router.post("/send/init", async (req, res) => {
  try {
    const { userId, receiverWalletAddress, amount, category, memo } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    const client = await getClient();

    const senderWalletAddress = await client.walletAddress.get({
      url: user.wallet_address,
    });
    const receiverWalletAddressInfo = await client.walletAddress.get({
      url: receiverWalletAddress,
    });

    // b) grant for incoming payment on receiver's resource server
    const incomingGrant = await client.grant.request(
      { url: receiverWalletAddressInfo.authServer },
      {
        access_token: {
          access: [{ type: "incoming-payment", actions: ["create"] }],
        },
      }
    );

    // c) create incoming payment on receiver's wallet
    const incomingPayment = await client.incomingPayment.create(
      {
        url: receiverWalletAddressInfo.resourceServer,
        accessToken: incomingGrant.access_token.value,
      },
      {
        walletAddress: receiverWalletAddressInfo.id,
        incomingAmount: {
          value: toMinorUnits(amount, receiverWalletAddressInfo.assetScale),
          assetCode: receiverWalletAddressInfo.assetCode,
          assetScale: receiverWalletAddressInfo.assetScale,
        },
      }
    );

    // d) grant + create quote on sender's wallet
    const quoteGrant = await client.grant.request(
      { url: senderWalletAddress.authServer },
      { access_token: { access: [{ type: "quote", actions: ["create"] }] } }
    );

    const quote = await client.quote.create(
      {
        url: senderWalletAddress.resourceServer,
        accessToken: quoteGrant.access_token.value,
      },
      {
        walletAddress: senderWalletAddress.id,
        receiver: incomingPayment.id,
        method: "ilp",
      }
    );

    // e) grant for outgoing payment - this needs user interaction/approval
    const outgoingGrant = await client.grant.request(
      { url: senderWalletAddress.authServer },
      {
        access_token: {
          access: [
            {
              type: "outgoing-payment",
              actions: ["create"],
              limits: { debitAmount: quote.debitAmount },
              identifier: senderWalletAddress.id,
            },
          ],
        },
        interact: {
          start: ["redirect"],
          finish: {
            method: "redirect",
            uri: `${process.env.REDIRECT_URI}?userId=${userId}`,
            nonce: uuid(),
          },
        },
      }
    );

    // Save pending state so we can finish the payment after user approves
    db.prepare(
      `INSERT INTO pending_grants (id, user_id, quote_id, continue_uri, continue_access_token, receiver, amount, category, memo)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      outgoingGrant.continue.access_token.value, // use as lookup key too
      userId,
      quote.id,
      outgoingGrant.continue.uri,
      outgoingGrant.continue.access_token.value,
      receiverWalletAddress,
      amount,
      category || "General",
      memo || null
    );

    // Frontend redirects the user's browser to this URL to approve the payment
    res.json({
      redirectUrl: outgoingGrant.interact.redirect,
      continueToken: outgoingGrant.continue.access_token.value,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * STEP 2: Wallet provider redirects user back here (REDIRECT_URI) after approval.
 * We then "continue" the grant to get the final access token, and execute
 * the actual outgoing payment.
 */
router.get("/callback", async (req, res) => {
  try {
    const { userId, continueToken } = { ...req.query };
    const token = continueToken || req.query.interact_ref; // depends on provider

    const pending = db
      .prepare("SELECT * FROM pending_grants WHERE user_id = ? ORDER BY created_at DESC LIMIT 1")
      .get(userId);
    if (!pending) return res.status(404).send("No pending payment found");

    const client = await getClient();

    const finalizedGrant = await client.grant.continue(
      {
        url: pending.continue_uri,
        accessToken: pending.continue_access_token,
      },
      { interact_ref: req.query.interact_ref }
    );

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
    const senderWalletAddress = await client.walletAddress.get({
      url: user.wallet_address,
    });

    const outgoingPayment = await client.outgoingPayment.create(
      {
        url: senderWalletAddress.resourceServer,
        accessToken: finalizedGrant.access_token.value,
      },
      {
        walletAddress: senderWalletAddress.id,
        quoteId: pending.quote_id,
      }
    );

    db.prepare(
      `INSERT INTO transactions (id, user_id, direction, counterparty_wallet, amount, status, interledger_id, category, memo)
       VALUES (?, ?, 'sent', ?, ?, 'completed', ?, ?, ?)`
    ).run(uuid(), userId, pending.receiver, pending.amount, outgoingPayment.id, pending.category || "General", pending.memo || null);

    // Update the payment request status and requester's pending transaction to completed
    db.prepare("UPDATE payment_requests SET status = 'completed' WHERE incoming_payment_url = ?").run(pending.receiver);
    db.prepare("UPDATE transactions SET status = 'completed' WHERE interledger_id = ?").run(pending.receiver);

    db.prepare("DELETE FROM pending_grants WHERE id = ?").run(pending.id);

    // Redirect back to your React app's "success" page
    res.redirect(`${process.env.PUBLIC_BASE_URL}/payment-success`);
  } catch (err) {
    console.error(err);
    res.status(500).send("Payment failed: " + err.message);
  }
});

/**
 * Generate a "request money" link: creates an incoming payment for the
 * logged-in user's own wallet, which anyone else's app can pay into.
 * This is how this user RECEIVES funds.
 */
router.post("/receive/request", async (req, res) => {
  try {
    const { userId, amount, category, memo } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
    const client = await getClient();

    const walletAddress = await client.walletAddress.get({ url: user.wallet_address });

    const grant = await client.grant.request(
      { url: walletAddress.authServer },
      { access_token: { access: [{ type: "incoming-payment", actions: ["create", "read"] }] } }
    );

    const incomingPayment = await client.incomingPayment.create(
      {
        url: walletAddress.resourceServer,
        accessToken: grant.access_token.value,
      },
      {
        walletAddress: walletAddress.id,
        incomingAmount: amount
          ? {
              value: toMinorUnits(amount, walletAddress.assetScale),
              assetCode: walletAddress.assetCode,
              assetScale: walletAddress.assetScale,
            }
          : undefined,
      }
    );

    db.prepare(
      `INSERT INTO transactions (id, user_id, direction, amount, status, interledger_id, category, memo)
       VALUES (?, ?, 'received', ?, 'pending', ?, ?, ?)`
    ).run(uuid(), userId, amount || "0", incomingPayment.id, category || "General", memo || null);

    const requestId = uuid();
    db.prepare(
      `INSERT INTO payment_requests (id, requester_id, incoming_payment_url, amount, category, memo)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(requestId, userId, incomingPayment.id, amount || null, category || "General", memo || null);

    res.json({ requestId, incomingPaymentUrl: incomingPayment.id, walletAddress: walletAddress.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /requests/:id: Retrieve payment request details.
 */
router.get("/requests/:id", async (req, res) => {
  try {
    const request = db.prepare(
      `SELECT pr.id, pr.amount, pr.category, pr.memo, pr.incoming_payment_url, pr.status, u.email, u.wallet_address as requester_wallet
       FROM payment_requests pr
       JOIN users u ON pr.requester_id = u.id
       WHERE pr.id = ?`
    ).get(req.params.id);

    if (!request) {
      return res.status(404).json({ error: "Payment request not found" });
    }

    res.json({
      id: request.id,
      amount: request.amount,
      category: request.category,
      memo: request.memo,
      incomingPaymentUrl: request.incoming_payment_url,
      status: request.status,
      requester: {
        email: request.email,
        walletAddress: request.requester_wallet
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /requests/:id/pay: Execute a payment request.
 */
router.post("/requests/:id/pay", async (req, res) => {
  try {
    const { payerId } = req.body;
    if (!payerId) {
      return res.status(400).json({ error: "payerId is required" });
    }

    const paymentRequest = db.prepare("SELECT * FROM payment_requests WHERE id = ?").get(req.params.id);
    if (!paymentRequest) {
      return res.status(404).json({ error: "Payment request not found" });
    }

    const payer = db.prepare("SELECT * FROM users WHERE id = ?").get(payerId);
    if (!payer) {
      return res.status(404).json({ error: "Payer not found" });
    }

    const client = await getClient();

    // Sender (payer) wallet address info
    const senderWalletAddress = await client.walletAddress.get({
      url: payer.wallet_address,
    });

    // Request grant for quote on sender's wallet, then create quote
    const quoteGrant = await client.grant.request(
      { url: senderWalletAddress.authServer },
      { access_token: { access: [{ type: "quote", actions: ["create"] }] } }
    );

    const quote = await client.quote.create(
      {
        url: senderWalletAddress.resourceServer,
        accessToken: quoteGrant.access_token.value,
      },
      {
        walletAddress: senderWalletAddress.id,
        receiver: paymentRequest.incoming_payment_url,
        method: "ilp",
      }
    );

    // Request grant for outgoing payment
    const outgoingGrant = await client.grant.request(
      { url: senderWalletAddress.authServer },
      {
        access_token: {
          access: [
            {
              type: "outgoing-payment",
              actions: ["create"],
              limits: { debitAmount: quote.debitAmount },
              identifier: senderWalletAddress.id,
            },
          ],
        },
        interact: {
          start: ["redirect"],
          finish: {
            method: "redirect",
            uri: `${process.env.REDIRECT_URI}?userId=${payerId}`,
            nonce: uuid(),
          },
        },
      }
    );

    // Save pending grant
    db.prepare(
      `INSERT INTO pending_grants (id, user_id, quote_id, continue_uri, continue_access_token, receiver, amount, category, memo)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      outgoingGrant.continue.access_token.value,
      payerId,
      quote.id,
      outgoingGrant.continue.uri,
      outgoingGrant.continue.access_token.value,
      paymentRequest.incoming_payment_url,
      paymentRequest.amount || "0",
      paymentRequest.category || "General",
      paymentRequest.memo || null
    );

    res.json({
      redirectUrl: outgoingGrant.interact.redirect,
      continueToken: outgoingGrant.continue.access_token.value
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

function toMinorUnits(amount, scale) {
  return Math.round(parseFloat(amount) * 10 ** scale).toString();
}

export default router;
