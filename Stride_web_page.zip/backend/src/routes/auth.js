import express from "express";
import { v4 as uuid } from "uuid";
import db from "../lib/db.js";
import { getClient } from "../lib/opClient.js";

const router = express.Router();

// Create a user account: email + their own Interledger wallet address
// (the user creates this wallet address themselves at wallet.interledger-test.dev
//  and pastes it in during signup — we just verify it resolves)
router.post("/signup", async (req, res) => {
  try {
    const { email, walletAddress } = req.body;
    if (!email || !walletAddress) {
      return res.status(400).json({ error: "email and walletAddress are required" });
    }

    // Verify the wallet address is real/reachable before saving
    const client = await getClient();
    const resolved = await client.walletAddress.get({ url: walletAddress });

    const id = uuid();
    db.prepare(
      "INSERT INTO users (id, email, wallet_address) VALUES (?, ?, ?)"
    ).run(id, email, resolved.id);

    res.json({ id, email, walletAddress: resolved.id, assetCode: resolved.assetCode });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: "Invalid wallet address or " + err.message });
  }
});
// Login: look up user by email
router.post("/login", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: "email is required" });
    }
    const user = db.prepare("SELECT id, email, wallet_address FROM users WHERE email = ?").get(email);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

router.get("/me/:userId", (req, res) => {
  const user = db.prepare("SELECT id, email, wallet_address, created_at FROM users WHERE id = ?").get(req.params.userId);
  if (!user) return res.status(404).json({ error: "Not found" });
  res.json(user);
});

export default router;
