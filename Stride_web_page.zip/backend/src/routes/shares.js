import express from "express";
import { v4 as uuid } from "uuid";
import db from "../lib/db.js";

const router = express.Router();

// Generate a new shared link
router.post("/", (req, res) => {
  try {
    const userId = req.body.userId || req.body.user_id;
    const institutionName = req.body.institutionName || req.body.institution_name;

    if (!userId || !institutionName) {
      return res.status(400).json({ error: "userId and institutionName are required" });
    }

    const id = uuid();
    db.prepare(
      "INSERT INTO shared_links (id, user_id, institution_name) VALUES (?, ?, ?)"
    ).run(id, userId, institutionName);

    res.json({ id, userId, institutionName });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// List all active shared links for a user
router.get("/:userId", (req, res) => {
  try {
    const { userId } = req.params;
    const rows = db
      .prepare("SELECT * FROM shared_links WHERE user_id = ? ORDER BY created_at DESC")
      .all(userId);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Delete a shared link (Revoke access)
router.delete("/:id", (req, res) => {
  try {
    const { id } = req.params;
    const result = db.prepare("DELETE FROM shared_links WHERE id = ?").run(id);
    if (result.changes === 0) {
      return res.status(404).json({ error: "Shared link not found" });
    }
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Public read-only connection endpoint
router.get("/public/:token", (req, res) => {
  try {
    const { token } = req.params;
    const share = db.prepare("SELECT * FROM shared_links WHERE id = ?").get(token);
    if (!share) {
      return res.status(404).json({ error: "Shared link not found or has been revoked" });
    }

    const transactions = db
      .prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC")
      .all(share.user_id);

    const spent = db
      .prepare(
        "SELECT COALESCE(SUM(CAST(amount AS REAL)),0) as total FROM transactions WHERE user_id = ? AND direction = 'sent' AND status = 'completed'"
      )
      .get(share.user_id);

    const received = db
      .prepare(
        "SELECT COALESCE(SUM(CAST(amount AS REAL)),0) as total FROM transactions WHERE user_id = ? AND direction = 'received' AND status = 'completed'"
      )
      .get(share.user_id);

    res.json({
      institutionName: share.institution_name,
      transactions,
      summary: {
        totalSpent: spent.total,
        totalReceived: received.total
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
