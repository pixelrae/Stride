import express from "express";
import db from "../lib/db.js";

const router = express.Router();

router.get("/:userId", (req, res) => {
  const rows = db
    .prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC")
    .all(req.params.userId);
  res.json(rows);
});

// Summary stats: total spent, total received, broken down however the dashboard needs
router.get("/:userId/summary", (req, res) => {
  const { userId } = req.params;
  const spent = db
    .prepare(
      "SELECT COALESCE(SUM(CAST(amount AS REAL)),0) as total FROM transactions WHERE user_id = ? AND direction = 'sent' AND status = 'completed'"
    )
    .get(userId);
  const received = db
    .prepare(
      "SELECT COALESCE(SUM(CAST(amount AS REAL)),0) as total FROM transactions WHERE user_id = ? AND direction = 'received' AND status = 'completed'"
    )
    .get(userId);
  res.json({ totalSpent: spent.total, totalReceived: received.total });
});

export default router;
