import Database from 'better-sqlite3';
const db = new Database('test.db');
db.exec('CREATE TABLE IF NOT EXISTS test (id TEXT)');
try { db.prepare('SELECT category FROM test LIMIT 1').get(); } catch (e) { db.exec('ALTER TABLE test ADD COLUMN category TEXT DEFAULT "General"; ALTER TABLE test ADD COLUMN memo TEXT;'); }
console.log(db.prepare('PRAGMA table_info(test)').all());
