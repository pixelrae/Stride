import express from "express";
import cors from "cors";
import "dotenv/config";

import authRoutes from "./src/routes/auth.js";
import paymentsRoutes from "./src/routes/payments.js";
import transactionsRoutes from "./src/routes/transactions.js";
import sharesRoutes from "./src/routes/shares.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/transactions", transactionsRoutes);
app.use("/api/shares", sharesRoutes);

app.get("/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`STRIDE backend running on port ${PORT}`));
