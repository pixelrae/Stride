import { Outlet } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="app-shell">
      <header>
        <Navbar />
      </header>
      <main style={{ flex: "1 0 auto" }}>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
