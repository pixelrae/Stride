import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { api } from "../lib/api";

export default function PayRequest() {
  const { requestId } = useParams();
  const navigate = useNavigate();
  const [requestDetails, setRequestDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState("");
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    async function fetchRequest() {
      try {
        const details = await api.getRequestDetails(requestId);
        setRequestDetails(details);
      } catch (err) {
        setError(err.message || "Failed to load payment request");
      } finally {
        setLoading(false);
      }
    }
    fetchRequest();
  }, [requestId]);

  const handlePay = async () => {
    if (!userId) return;
    setPaying(true);
    setError("");
    try {
      const result = await api.payRequest(requestId, userId);
      if (result.redirectUrl) {
        window.location.href = result.redirectUrl;
      } else {
        throw new Error("No redirect URL returned from payment server");
      }
    } catch (err) {
      setError(err.message || "Failed to initiate payment");
      setPaying(false);
    }
  };

  if (loading) {
    return (
      <div className="auth-container">
        <div className="glass-card" style={{ textAlign: "center", padding: "40px" }}>
          <div className="spinner" style={{
            width: "36px",
            height: "36px",
            border: "3px solid rgba(15, 23, 42, 0.08)",
            borderTop: "3px solid var(--color-cobalt)",
            borderRadius: "50%",
            margin: "0 auto 16px",
            animation: "spin 1s linear infinite"
          }}></div>
          <p style={{ color: "var(--color-text-secondary)", margin: 0, fontWeight: 500 }}>
            Loading payment request...
          </p>
          <style dangerouslySetInnerHTML={{__html: `
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}} />
        </div>
      </div>
    );
  }

  if (error && !requestDetails) {
    return (
      <div className="auth-container">
        <div className="glass-card error" style={{ textAlign: "center", padding: "40px" }}>
          <div style={{
            width: "48px",
            height: "48px",
            borderRadius: "50%",
            background: "rgba(220, 38, 38, 0.1)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 16px",
            color: "#DC2626"
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
          </div>
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "8px" }}>Request Failed</h2>
          <p style={{ margin: "0 0 24px" }}>{error}</p>
          <Link to="/" className="hero-btn-primary" style={{ display: "inline-block", textDecoration: "none" }}>
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  const { amount, category, memo, status, requester } = requestDetails;
  const isCompleted = status === "completed";

  return (
    <div className="auth-container">
      <div className="glass-card">
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <div style={{
            width: "48px",
            height: "48px",
            borderRadius: "12px",
            background: "rgba(37, 99, 235, 0.08)",
            color: "var(--color-cobalt)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 16px"
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="1" x2="12" y2="23"></line>
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
            </svg>
          </div>
          <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--color-navy)", margin: 0 }}>
            {isCompleted ? "Payment Completed" : "Authorize Payment"}
          </h2>
          <p style={{ color: "var(--color-text-secondary)", fontSize: "14px", marginTop: "6px" }}>
            Requested by <strong style={{ color: "var(--color-navy)" }}>{requester.email}</strong>
          </p>
        </div>

        <div style={{ 
          background: "var(--color-ice-dark)", 
          borderRadius: "10px", 
          padding: "20px", 
          marginBottom: "24px",
          border: "1px solid var(--color-border)"
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
            <span style={{ color: "var(--color-text-secondary)", fontSize: "14px" }}>Amount Requested</span>
            <span style={{ fontWeight: 700, color: "var(--color-navy)", fontSize: "18px" }}>
              {amount ? `R ${Number(amount).toLocaleString("en-ZA", { minimumFractionDigits: 2 })}` : "Open amount"}
            </span>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "12px" }}>
            <span style={{ color: "var(--color-text-secondary)", fontSize: "14px" }}>Category</span>
            <span style={{ fontWeight: 500, color: "var(--color-navy)", fontSize: "14px" }}>{category || "General"}</span>
          </div>

          {memo && (
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "var(--color-text-secondary)", fontSize: "14px" }}>Memo</span>
              <span style={{ fontWeight: 500, color: "var(--color-navy)", fontSize: "14px", maxWidth: "60%", textAlign: "right" }}>{memo}</span>
            </div>
          )}
        </div>

        {error && (
          <div style={{
            padding: "12px 16px",
            borderRadius: "8px",
            background: "rgba(220, 38, 38, 0.1)",
            color: "#DC2626",
            fontSize: "14px",
            fontWeight: 600,
            marginBottom: "20px",
            textAlign: "center"
          }}>
            {error}
          </div>
        )}

        {isCompleted ? (
          <div style={{ textAlign: "center" }}>
            <div style={{ 
              color: "#10B981", 
              fontWeight: 600, 
              display: "flex", 
              alignItems: "center", 
              justifyContent: "center", 
              gap: "6px",
              marginBottom: "20px"
            }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
              Payment Cleared Successfully
            </div>
            <Link to="/dashboard" className="hero-btn-primary" style={{ display: "block", textDecoration: "none", textAlign: "center" }}>
              Go to Dashboard
            </Link>
          </div>
        ) : !userId ? (
          <div>
            <p style={{ fontSize: "13px", color: "var(--color-text-secondary)", textAlign: "center", marginBottom: "16px" }}>
              You must log in to your STRIDE account to pay this request.
            </p>
            <Link 
              to={`/login?returnTo=/pay/${requestId}`} 
              className="hero-btn-primary" 
              style={{ display: "block", textDecoration: "none", textAlign: "center" }}
            >
              Log in to Pay
            </Link>
          </div>
        ) : (
          <button 
            onClick={handlePay}
            disabled={paying}
            className="hero-btn-primary"
            style={{ width: "100%", height: "48px", display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            {paying ? (
              <div className="spinner" style={{
                width: "20px",
                height: "20px",
                border: "2px solid rgba(255, 255, 255, 0.2)",
                borderTop: "2px solid white",
                borderRadius: "50%",
                animation: "spin 1s linear infinite"
              }}></div>
            ) : "Approve & Pay"}
          </button>
        )}
      </div>
    </div>
  );
}
