import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

export default function Landing() {
  const [amount, setAmount] = useState(1250);
  const [payStatus, setPayStatus] = useState("idle"); // idle | processing | success

  const handleSimulatePayment = () => {
    setPayStatus("processing");
  };

  useEffect(() => {
    if (payStatus === "processing") {
      const timer = setTimeout(() => {
        setPayStatus("success");
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [payStatus]);

  const handleReset = () => {
    setPayStatus("idle");
  };

  return (
    <div className="landing-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-container">
          <span className="hero-tag">Localized Payment Infrastructure</span>
          <h1 className="hero-title">
            Secure, Instant Payments for <span>South African</span> Enterprise.
          </h1>
          <p className="hero-subtitle">
            Accept cards, process Instant EFTs, and mitigate fraud with a unified, high-conversion payments API built for institutional trust.
          </p>
          <div className="hero-actions">
            <Link to="/signup" className="hero-btn-primary">
              Create Free Account
            </Link>
            <a href="#features" className="hero-btn-secondary">
              Explore Features
            </a>
          </div>

          {/* Interactive Mockup Container */}
          <div className="hero-mockup-wrapper">
            <div className="mockup-glass">
              {payStatus === "idle" && (
                <div>
                  <div className="mockup-header">
                    <div>
                      <span className="mockup-dot"></span>
                      <span className="mockup-dot"></span>
                      <span className="mockup-dot"></span>
                    </div>
                    <span className="mockup-status" style={{ color: "#E2E8F0", background: "rgba(255,255,255,0.08)" }}>
                      Terminal Idle
                    </span>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                    <div>
                      <label style={{ color: "#94A3B8", fontSize: "12px", textTransform: "uppercase" }}>
                        Simulated Amount (ZAR)
                      </label>
                      <div className="mockup-amount">R {amount.toLocaleString("en-ZA")}.00</div>
                      <input
                        type="range"
                        min="100"
                        max="10000"
                        step="100"
                        value={amount}
                        onChange={(e) => setAmount(Number(e.target.value))}
                        style={{ width: "100%", accentColor: "var(--color-cobalt)", cursor: "pointer", marginTop: "8px" }}
                      />
                    </div>
                    
                    <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px", padding: "12px", background: "rgba(255,255,255,0.03)" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "14px", color: "#E2E8F0" }}>
                        <span>Merchant Account</span>
                        <span style={{ fontWeight: 600 }}>STRIDE PAYMENTS (PTY) LTD</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "14px", color: "#E2E8F0", marginTop: "8px" }}>
                        <span>Supported Banks</span>
                        <span style={{ fontSize: "12px", color: "#94A3B8" }}>FNB, Capitec, ABSA, Nedbank +</span>
                      </div>
                    </div>

                    <button 
                      onClick={handleSimulatePayment}
                      style={{ 
                        background: "var(--color-cobalt)", 
                        color: "white", 
                        border: "none", 
                        padding: "14px", 
                        borderRadius: "10px", 
                        fontWeight: 700,
                        cursor: "pointer",
                        boxShadow: "0 4px 14px rgba(37, 99, 235, 0.4)",
                        transition: "all 0.2s"
                      }}
                    >
                      Process Instant EFT Payment
                    </button>
                  </div>
                </div>
              )}

              {payStatus === "processing" && (
                <div style={{ padding: "40px 0", textAlign: "center" }}>
                  <div style={{
                    width: "48px",
                    height: "48px",
                    border: "3px stroke rgba(255,255,255,0.2)",
                    borderTop: "3px solid var(--color-cobalt)",
                    borderRadius: "50%",
                    margin: "0 auto 20px",
                    animation: "spin 1s linear infinite"
                  }} className="spinner"></div>
                  <h4 style={{ color: "white", margin: "0 0 8px", fontSize: "18px" }}>Connecting Gateway</h4>
                  <p style={{ color: "#94A3B8", fontSize: "14px", margin: 0 }}>
                    Securing bank-grade transaction of R {amount.toLocaleString("en-ZA")}.00 via 3D Secure 2.0...
                  </p>
                  <style dangerouslySetInnerHTML={{__html: `
                    @keyframes spin {
                      0% { transform: rotate(0deg); }
                      100% { transform: rotate(360deg); }
                    }
                  `}} />
                </div>
              )}

              {payStatus === "success" && (
                <div>
                  <div className="mockup-header">
                    <div>
                      <span className="mockup-dot"></span>
                      <span className="mockup-dot"></span>
                      <span className="mockup-dot"></span>
                    </div>
                    <span className="mockup-status">Approved</span>
                  </div>
                  <div style={{ textAlign: "center", padding: "10px 0" }}>
                    <div style={{ 
                      width: "56px", 
                      height: "56px", 
                      borderRadius: "50%", 
                      background: "rgba(16, 185, 129, 0.15)", 
                      display: "flex", 
                      alignItems: "center", 
                      justifyContent: "center", 
                      margin: "0 auto 16px",
                      border: "2px solid #10B981"
                    }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <h3 style={{ color: "white", fontSize: "22px", margin: "0 0 4px" }}>Transaction Successful</h3>
                    <p style={{ color: "#94A3B8", fontSize: "14px", margin: "0 0 24px" }}>Funds cleared in real-time</p>
                    
                    <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px", padding: "16px", textAlign: "left", display: "flex", flexDirection: "column", gap: "8px", marginBottom: "24px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px" }}>
                        <span style={{ color: "#94A3B8" }}>Amount Paid</span>
                        <span style={{ color: "white", fontWeight: 600 }}>R {amount.toLocaleString("en-ZA")}.00</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px" }}>
                        <span style={{ color: "#94A3B8" }}>Settlement Method</span>
                        <span style={{ color: "white", fontWeight: 600 }}>Instant EFT (FNB Capitec API)</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px" }}>
                        <span style={{ color: "#94A3B8" }}>Reference ID</span>
                        <span style={{ color: "white", fontFamily: "monospace" }}>STRIDE-ZA-8902B</span>
                      </div>
                    </div>

                    <button 
                      onClick={handleReset}
                      style={{ 
                        background: "rgba(255, 255, 255, 0.08)", 
                        color: "white", 
                        border: "1px solid rgba(255, 255, 255, 0.15)", 
                        padding: "10px 20px", 
                        borderRadius: "8px", 
                        fontWeight: 600,
                        cursor: "pointer",
                        transition: "all 0.2s"
                      }}
                    >
                      Reset Simulator
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Bento Grid Feature Section */}
      <section id="features" className="features-section">
        <div className="section-header">
          <span className="section-tag">Powerful Suite</span>
          <h2 className="section-title">Institutional Features. Premium Simplicity.</h2>
          <p className="section-subtitle">
            Scale your digital commerce with localized South African tools designed to boost transactional performance and reliability.
          </p>
        </div>

        <div className="bento-grid">
          {/* Card 1: Instant EFT */}
          <div className="bento-card bento-card-highlight">
            <div>
              <div className="bento-icon-wrapper">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                </svg>
              </div>
              <h3>Instant EFT</h3>
              <p>
                Settle payments instantly using direct API integrations with South Africa's major banks. Zero manual references needed; automatic reconciliation is standard.
              </p>
            </div>
          </div>

          {/* Card 2: Card Processing */}
          <div className="bento-card">
            <div>
              <div className="bento-icon-wrapper">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                  <line x1="1" y1="10" x2="23" y2="10"></line>
                </svg>
              </div>
              <h3>Card Processing</h3>
              <p>
                Accept Visa, Mastercard, and American Express locally. Secure credit and debit processing optimized for low latency and high transaction success rates.
              </p>
            </div>
          </div>

          {/* Card 3: Fraud Prevention */}
          <div className="bento-card">
            <div>
              <div className="bento-icon-wrapper">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
              </div>
              <h3>Fraud Prevention</h3>
              <p>
                AI-driven real-time fraud monitoring customized for South Africa. Detect high-risk patterns immediately and protect your margins from chargeback risk.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
