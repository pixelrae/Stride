import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { api } from "../lib/api";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleWalletAddressChange = (e) => {
    let value = e.target.value;
    if (value.startsWith("$")) {
      value = "https://" + value.slice(1);
    }
    setWalletAddress(value);
  };

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    let address = walletAddress.trim();
    if (address.startsWith("$")) {
      address = "https://" + address.slice(1);
    }
    try {
      const user = await api.signup(email, address);
      localStorage.setItem("userId", user.id);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="auth-container">
      <div className="glass-card">
        <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--color-navy)", marginTop: 0, marginBottom: "8px" }}>Create your account</h2>
        <p className="hint" style={{ marginBottom: "24px" }}>
          Don't have an Interledger wallet yet? Create one free at{" "}
          <a href="https://wallet.interledger-test.dev" target="_blank" rel="noreferrer" style={{ color: "var(--color-cobalt)", fontWeight: "500" }}>
            wallet.interledger-test.dev
          </a>{" "}
          then paste your wallet address below.
        </p>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>

          <div className="form-group">
            <label>Wallet address</label>
            <input
              type="url"
              required
              placeholder="https://ilp.interledger-test.dev/yourname"
              value={walletAddress}
              onChange={handleWalletAddressChange}
            />
          </div>

          {error && <p className="error" style={{ margin: "0" }}>{error}</p>}
          <button type="submit" style={{ marginTop: "8px" }}>Create Account</button>
        </form>
        <p className="hint" style={{ marginTop: "20px", marginBottom: "0", textAlign: "center" }}>
          Already have an account? <Link to="/login" style={{ color: "var(--color-cobalt)", fontWeight: "600", textDecoration: "none" }}>Log in</Link>
        </p>
      </div>
    </div>
  );
}
