import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { QRCodeSVG } from "qrcode.react";

export default function Dashboard() {
  const userId = localStorage.getItem("userId");
  const navigate = useNavigate();
  const [summary, setSummary] = useState({ totalSpent: 0, totalReceived: 0 });
  const [transactions, setTransactions] = useState([]);
  const [receiverWallet, setReceiverWallet] = useState("");
  const [sendAmount, setSendAmount] = useState("");
  const [receiveAmount, setReceiveAmount] = useState("");
  const [receiveLink, setReceiveLink] = useState(null);
  const [requestId, setRequestId] = useState(null);
  const [status, setStatus] = useState("");
  const [sendCategory, setSendCategory] = useState("General");
  const [sendMemo, setSendMemo] = useState("");
  const [receiveCategory, setReceiveCategory] = useState("General");
  const [receiveMemo, setReceiveMemo] = useState("");
  const [shares, setShares] = useState([]);
  const [institutionName, setInstitutionName] = useState("");

  useEffect(() => {
    if (!userId) {
      navigate("/login");
      return;
    }
    refresh();
  }, [userId, navigate]);

  const handleLogout = () => {
    localStorage.removeItem("userId");
    navigate("/login");
  };

  async function refresh() {
    if (!userId) return;
    setSummary(await api.summary(userId));
    setTransactions(await api.transactions(userId));
    setShares(await api.getShares(userId));
  }

  const handleReceiverWalletChange = (e) => {
    let value = e.target.value;
    if (value.startsWith("$")) {
      value = "https://" + value.slice(1);
    }
    setReceiverWallet(value);
  };

  async function handleSend(e) {
    e.preventDefault();
    setStatus("Starting payment...");
    try {
      let address = receiverWallet.trim();
      if (address.startsWith("$")) {
        address = "https://" + address.slice(1);
      }
      const { redirectUrl } = await api.initSend(userId, address, sendAmount, sendCategory, sendMemo);
      // Redirect the user to their wallet provider to approve the payment.
      // They'll be sent back to /api/payments/callback -> /payment-success
      window.location.href = redirectUrl;
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  }

  async function handleReceiveRequest(e) {
    e.preventDefault();
    setStatus("Generating payment request...");
    try {
      const result = await api.requestReceive(userId, receiveAmount, receiveCategory, receiveMemo);
      setReceiveLink(result.incomingPaymentUrl);
      setRequestId(result.requestId);
      setStatus("");
      refresh();
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  }

  async function handleCreateShare(e) {
    e.preventDefault();
    if (!institutionName.trim()) return;
    setStatus("Creating shared link...");
    try {
      await api.createShare(userId, institutionName);
      setInstitutionName("");
      setStatus("");
      refresh();
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  }

  async function handleRevokeShare(id) {
    setStatus("Revoking shared link...");
    try {
      await api.deleteShare(id);
      setStatus("");
      refresh();
    } catch (err) {
      setStatus("Error: " + err.message);
    }
  }

  function handleExportCSV() {
    const headers = ["ID", "Date", "Direction", "Counterparty", "Amount", "Category", "Memo", "Status"];
    const rows = transactions.map(t => [
      t.id,
      new Date(t.created_at).toLocaleString(),
      t.direction,
      t.counterparty_wallet || "-",
      t.amount,
      t.category,
      t.memo || "-",
      t.status
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "transactions.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function handleExportPDF() {
    const doc = new jsPDF();
    doc.text("Transaction History", 14, 15);
    autoTable(doc, {
      startY: 20,
      head: [["Date", "Direction", "Counterparty", "Amount", "Category", "Memo", "Status"]],
      body: transactions.map(t => [
        new Date(t.created_at).toLocaleString(),
        t.direction,
        t.counterparty_wallet || "-",
        t.amount,
        t.category,
        t.memo || "-",
        t.status
      ])
    });
    doc.save("transactions.pdf");
  }

  return (
    <div className="dashboard-container">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "32px" }}>
        <h2 style={{ margin: 0, fontSize: "28px", fontWeight: 800, color: "var(--color-navy)" }}>Dashboard</h2>
        <button onClick={handleLogout} style={{ background: "#EF4444", padding: "8px 16px", borderRadius: "8px", fontSize: "14px", fontWeight: 600 }}>
          Log out
        </button>
      </div>

      <div className="summary-grid" style={{ marginBottom: "32px" }}>
        <div className="glass-card stat">
          <h3>Total Sent</h3>
          <p>R {summary.totalSpent.toLocaleString("en-ZA")}</p>
        </div>
        <div className="glass-card stat">
          <h3>Total Received</h3>
          <p>R {summary.totalReceived.toLocaleString("en-ZA")}</p>
        </div>
      </div>

      <div className="two-col" style={{ marginBottom: "32px" }}>
        <div className="glass-card">
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "20px" }}>Send Money</h2>
          <form onSubmit={handleSend}>
            <div className="form-group">
              <label>Recipient Wallet Address</label>
              <input
                type="text"
                required
                placeholder="https://... or $ilp.interledger-test.dev/yourname"
                value={receiverWallet}
                onChange={handleReceiverWalletChange}
              />
            </div>
            <div className="form-group">
              <label>Amount (ZAR)</label>
              <input
                type="number"
                step="0.01"
                required
                value={sendAmount}
                onChange={(e) => setSendAmount(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Category</label>
              <select
                value={sendCategory}
                onChange={(e) => setSendCategory(e.target.value)}
              >
                <option value="General">General</option>
                <option value="Insurance">Insurance</option>
                <option value="Loan">Loan</option>
                <option value="Food">Food</option>
                <option value="Rent">Rent</option>
              </select>
            </div>
            <div className="form-group">
              <label>Memo</label>
              <input
                type="text"
                placeholder="E.g., Monthly premium"
                value={sendMemo}
                onChange={(e) => setSendMemo(e.target.value)}
              />
            </div>
            <button type="submit" style={{ marginTop: "8px" }}>Send Funds</button>
          </form>
        </div>

        <div className="glass-card">
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "20px" }}>Request Money</h2>
          <form onSubmit={handleReceiveRequest}>
            <div className="form-group">
              <label>Amount (ZAR - optional)</label>
              <input
                type="number"
                step="0.01"
                value={receiveAmount}
                onChange={(e) => setReceiveAmount(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Category</label>
              <select
                value={receiveCategory}
                onChange={(e) => setReceiveCategory(e.target.value)}
              >
                <option value="General">General</option>
                <option value="Insurance">Insurance</option>
                <option value="Loan">Loan</option>
                <option value="Food">Food</option>
                <option value="Rent">Rent</option>
              </select>
            </div>
            <div className="form-group">
              <label>Memo</label>
              <input
                type="text"
                placeholder="E.g., Loan request"
                value={receiveMemo}
                onChange={(e) => setReceiveMemo(e.target.value)}
              />
            </div>
            <button type="submit" style={{ marginTop: "8px" }}>Create Payment Request</button>
          </form>
          {receiveLink && requestId && (
            <div style={{ marginTop: "16px", background: "var(--color-ice-dark)", padding: "16px", borderRadius: "8px", border: "1px solid var(--color-border)", textAlign: "center" }}>
              <p className="hint" style={{ marginBottom: "16px", textAlign: "left", color: "var(--color-text-secondary)" }}>
                Share this native payment link or scan the QR code to pay: <br />
                <code style={{ wordBreak: "break-all", display: "inline-block", marginTop: "4px", color: "var(--color-cobalt)", fontWeight: "600" }}>
                  {window.location.origin}/pay/{requestId}
                </code>
              </p>
              <div style={{ background: "white", padding: "16px", display: "inline-block", borderRadius: "8px", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
                <QRCodeSVG value={`${window.location.origin}/pay/${requestId}`} size={160} level="M" />
              </div>
            </div>
          )}
        </div>
      </div>


      {status && (
        <div style={{
          padding: "12px 16px",
          borderRadius: "8px",
          background: status.startsWith("Error") ? "rgba(220, 38, 38, 0.1)" : "rgba(37, 99, 235, 0.1)",
          color: status.startsWith("Error") ? "#dc2626" : "var(--color-cobalt)",
          fontSize: "14px",
          fontWeight: 600,
          marginBottom: "24px"
        }}>
          {status}
        </div>
      )}

      <div className="glass-card" style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "20px" }}>Transaction History</h2>
        <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Direction</th>
                <th>Counterparty</th>
                <th>Amount (ZAR)</th>
                <th>Category</th>
                <th>Memo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id}>
                  <td>{new Date(t.created_at).toLocaleString()}</td>
                  <td style={{ fontWeight: 600, color: t.direction === "OUTGOING" ? "#EF4444" : "#10B981" }}>
                    {t.direction}
                  </td>
                  <td style={{ fontFamily: "monospace", fontSize: "13px" }}>{t.counterparty_wallet || "-"}</td>
                  <td style={{ fontWeight: 600 }}>R {Number(t.amount).toLocaleString("en-ZA", { minimumFractionDigits: 2 })}</td>
                  <td>
                    <span style={{
                      background: "var(--color-ice-dark)",
                      padding: "4px 8px",
                      borderRadius: "6px",
                      fontSize: "12px",
                      fontWeight: 500
                    }}>
                      {t.category}
                    </span>
                  </td>
                  <td>{t.memo || "-"}</td>
                  <td>
                    <span style={{
                      fontSize: "12px",
                      fontWeight: 700,
                      textTransform: "uppercase",
                      color: t.status === "COMPLETED" ? "#10B981" : "#F59E0B"
                    }}>
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan="7" style={{ textAlign: "center", color: "var(--color-text-secondary)", padding: "24px" }}>
                    No transactions found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="glass-card" style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "12px" }}>Export Data</h2>
        <p className="hint" style={{ marginBottom: "20px" }}>Download your complete transaction history in CSV or PDF format.</p>
        <div style={{ display: "flex", gap: "12px" }}>
          <button onClick={handleExportCSV}>Export to CSV</button>
          <button onClick={handleExportPDF} style={{ background: "var(--color-ice-dark)", color: "var(--color-text-primary)", border: "1px solid var(--color-border)" }}>
            Export to PDF
          </button>
        </div>
      </div>

      <div className="glass-card" style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "12px" }}>
          In-App Data Sharing (External Connection)
        </h2>
        <p className="hint" style={{ marginBottom: "20px" }}>
          Generate secure, read-only links for external institutions to verify your transaction history.
        </p>
        
        <form onSubmit={handleCreateShare} style={{ display: "flex", gap: "16px", alignItems: "flex-end", flexWrap: "wrap", marginBottom: "24px" }}>
          <div style={{ flex: 1, minWidth: "250px" }} className="form-group">
            <label>Institution Name</label>
            <input
              type="text"
              required
              placeholder="E.g., Acme Insurance, SARS"
              value={institutionName}
              onChange={(e) => setInstitutionName(e.target.value)}
            />
          </div>
          <button type="submit" style={{ height: "45px" }}>Create Share Link</button>
        </form>

        {shares.length > 0 && (
          <div>
            <h3 style={{ fontSize: "16px", fontWeight: 600, color: "var(--color-navy)", marginBottom: "12px" }}>Active Connections</h3>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th>Institution</th>
                    <th>Secure Share URL</th>
                    <th style={{ textAlign: "right" }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {shares.map((share) => {
                    const shareUrl = `${window.location.origin}/shared/${share.id}`;
                    return (
                      <tr key={share.id}>
                        <td style={{ fontWeight: 600 }}>{share.institution_name}</td>
                        <td>
                          <code style={{ wordBreak: "break-all", color: "var(--color-cobalt)" }}>{shareUrl}</code>
                        </td>
                        <td style={{ textAlign: "right" }}>
                          <button
                            onClick={() => handleRevokeShare(share.id)}
                            style={{ background: "#EF4444", padding: "6px 12px", fontSize: "13px", margin: 0 }}
                          >
                            Revoke
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
