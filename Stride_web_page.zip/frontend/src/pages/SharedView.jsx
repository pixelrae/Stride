import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../lib/api";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

export default function SharedView() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const res = await api.getSharedData(token);
        setData(res);
      } catch (err) {
        setError(err.message || "Failed to load shared data");
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [token]);

  function handleExportCSV() {
    if (!data || !data.transactions) return;
    const headers = ["ID", "Date", "Direction", "Counterparty", "Amount", "Category", "Memo", "Status"];
    const rows = data.transactions.map(t => [
      t.id,
      new Date(t.created_at).toLocaleString(),
      t.direction,
      t.counterparty_wallet || "-",
      t.amount,
      t.category,
      t.memo || "-",
      t.status
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `shared_transactions_${data.institutionName.replace(/\s+/g, '_')}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function handleExportPDF() {
    if (!data || !data.transactions) return;
    const doc = new jsPDF();
    doc.text(`Transaction History - Shared with ${data.institutionName}`, 14, 15);
    autoTable(doc, {
      startY: 20,
      head: [["Date", "Direction", "Counterparty", "Amount", "Category", "Memo", "Status"]],
      body: data.transactions.map(t => [
        new Date(t.created_at).toLocaleString(),
        t.direction,
        t.counterparty_wallet || "-",
        t.amount,
        t.category,
        t.memo || "-",
        t.status
      ])
    });
    doc.save(`shared_transactions_${data.institutionName.replace(/\s+/g, '_')}.pdf`);
  }

  if (loading) {
    return (
      <div className="auth-container">
        <div className="glass-card" style={{ textAlign: "center", padding: "40px" }}>
          <p style={{ color: "var(--color-text-secondary)", margin: 0, fontWeight: 500 }}>Loading secure shared report...</p>
        </div>
      </div>
    );
  }
  if (error) {
    return (
      <div className="auth-container">
        <div className="glass-card error" style={{ textAlign: "center", padding: "40px" }}>
          <p style={{ margin: 0, fontWeight: 600 }}>{error}</p>
        </div>
      </div>
    );
  }

  const { institutionName, transactions, summary } = data;

  return (
    <div className="dashboard-container">
      <div className="glass-card" style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--color-navy)", marginTop: 0, marginBottom: "8px" }}>Secure Transaction Report</h2>
        <p style={{ color: "var(--color-text-secondary)", margin: 0 }}>
          This authenticated read-only report is securely shared with <strong>{institutionName}</strong>.
        </p>
      </div>

      <div className="summary-grid" style={{ marginBottom: "32px" }}>
        <div className="glass-card stat">
          <h3>Total Sent</h3>
          <p>R {summary.totalSpent.toLocaleString("en-ZA")}</p>
        </div>
        <div className="glass-card stat">
          <h3>Total Received</h3>
          <p>R {summary.totalReceived.toLocaleString("en-ZA")}</p>
        </div>
      </div>

      <div className="glass-card" style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "20px" }}>Transaction History</h2>
        <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Direction</th>
                <th>Counterparty</th>
                <th>Amount (ZAR)</th>
                <th>Category</th>
                <th>Memo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id}>
                  <td>{new Date(t.created_at).toLocaleString()}</td>
                  <td style={{ fontWeight: 600, color: t.direction === "OUTGOING" ? "#EF4444" : "#10B981" }}>
                    {t.direction}
                  </td>
                  <td style={{ fontFamily: "monospace", fontSize: "13px" }}>{t.counterparty_wallet || "-"}</td>
                  <td style={{ fontWeight: 600 }}>R {Number(t.amount).toLocaleString("en-ZA", { minimumFractionDigits: 2 })}</td>
                  <td>
                    <span style={{
                      background: "var(--color-ice-dark)",
                      padding: "4px 8px",
                      borderRadius: "6px",
                      fontSize: "12px",
                      fontWeight: 500
                    }}>
                      {t.category}
                    </span>
                  </td>
                  <td>{t.memo || "-"}</td>
                  <td>
                    <span style={{
                      fontSize: "12px",
                      fontWeight: 700,
                      textTransform: "uppercase",
                      color: t.status === "COMPLETED" ? "#10B981" : "#F59E0B"
                    }}>
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan="7" style={{ textAlign: "center", color: "var(--color-text-secondary)", padding: "24px" }}>
                    No transactions found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="glass-card">
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--color-navy)", marginTop: 0, marginBottom: "12px" }}>Export Data</h2>
        <p className="hint" style={{ marginBottom: "20px" }}>Download this shared report in CSV or PDF format.</p>
        <div style={{ display: "flex", gap: "12px" }}>
          <button onClick={handleExportCSV}>Export to CSV</button>
          <button onClick={handleExportPDF} style={{ background: "var(--color-ice-dark)", color: "var(--color-text-primary)", border: "1px solid var(--color-border)" }}>
            Export to PDF
          </button>
        </div>
      </div>
    </div>
  );
}
