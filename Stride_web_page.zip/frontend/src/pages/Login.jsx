import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { api } from "../lib/api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(window.location.search);
  const returnTo = queryParams.get("returnTo");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      const user = await api.login(email);
      localStorage.setItem("userId", user.id);
      navigate(returnTo || "/dashboard");
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="auth-container">
      <div className="glass-card">
        <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--color-navy)", marginTop: 0, marginBottom: "8px" }}>Log in to your account</h2>
        <p className="hint" style={{ marginBottom: "24px" }}>
          Enter your email to log in to your STRIDE account.
        </p>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          {error && <p className="error" style={{ margin: "0" }}>{error}</p>}
          <button type="submit" style={{ marginTop: "8px" }}>Log In</button>
        </form>
        <p className="hint" style={{ marginTop: "20px", marginBottom: "0", textAlign: "center" }}>
          Don't have an account? <Link to="/signup" style={{ color: "var(--color-cobalt)", fontWeight: "600", textDecoration: "none" }}>Sign up</Link>
        </p>
      </div>
    </div>
  );
}
