import { Link } from "react-router-dom";

export default function PaymentSuccess() {
  return (
    <div className="auth-container">
      <div className="glass-card" style={{ textAlign: "center", padding: "40px 32px" }}>
        <div style={{ 
          width: "56px", 
          height: "56px", 
          borderRadius: "50%", 
          background: "rgba(16, 185, 129, 0.15)", 
          display: "flex", 
          alignItems: "center", 
          justifyContent: "center", 
          margin: "0 auto 20px",
          border: "2px solid #10B981"
        }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </div>
        <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--color-navy)", marginTop: 0, marginBottom: "8px" }}>Payment Complete</h2>
        <p style={{ color: "var(--color-text-secondary)", fontSize: "15px", marginBottom: "28px" }}>
          Your transaction has been processed and cleared in real-time.
        </p>
        <Link to="/dashboard" className="hero-btn-primary" style={{ display: "inline-block", textDecoration: "none" }}>
          Return to Dashboard
        </Link>
      </div>
    </div>
  );
}
