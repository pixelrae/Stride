import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import App from "./App.jsx";
import Landing from "./pages/Landing.jsx";
import Signup from "./pages/Signup.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import PaymentSuccess from "./pages/PaymentSuccess.jsx";
import SharedView from "./pages/SharedView.jsx";
import PayRequest from "./pages/PayRequest.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />}>
        <Route index element={<Landing />} />
        <Route path="signup" element={<Signup />} />
        <Route path="login" element={<Login />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="payment-success" element={<PaymentSuccess />} />
        <Route path="shared/:token" element={<SharedView />} />
        <Route path="pay/:requestId" element={<PayRequest />} />
      </Route>
    </Routes>
  </BrowserRouter>
);
