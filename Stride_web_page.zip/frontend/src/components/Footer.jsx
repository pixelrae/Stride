import React from "react";

export default function Footer() {
  return (
    <footer>
      <div className="footer-container">
        <div className="footer-compliance">
          <div className="compliance-badge" title="PCI-DSS Level 1 Certified">
            <span className="compliance-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
              </svg>
            </span>
            <span>PCI-DSS Compliant</span>
          </div>

          <div className="compliance-badge" title="Bank-Grade 256-bit Encryption">
            <span className="compliance-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
              </svg>
            </span>
            <span>Bank-grade Encryption</span>
          </div>
          
          <div className="compliance-badge" title="FSCA Regulated Fintech">
            <span className="compliance-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
              </svg>
            </span>
            <span>FSCA Regulated</span>
          </div>
        </div>

        <div className="footer-proudly-sa">
          <span>Proudly South African</span>
          <span className="flag-badge" style={{ width: "20px", height: "20px" }}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="100%" height="100%">
              <rect width="60" height="40" fill="#002395"/>
              <rect width="60" height="20" fill="#E23D28"/>
              <path stroke="#FFFFFF" strokeWidth="13.3" fill="none" d="M0 0l30 20L0 40h60V0z"/>
              <path stroke="#007C3C" strokeWidth="8" fill="none" d="M0 0l30 20L0 40h60V0z"/>
              <path stroke="#FCB514" strokeWidth="6.7" fill="none" d="M0 0l20 13.3L0 26.7z"/>
              <path d="M0 0l15 10L0 20z" fill="#000000"/>
            </svg>
          </span>
        </div>

        <div className="footer-copyright">
          &copy; {new Date().getFullYear()} STRIDE. All rights reserved. STRIDE is a registered financial services provider.
        </div>
      </div>
    </footer>
  );
}
