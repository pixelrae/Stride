import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="nav-brand">
        STRIDE<span style={{ color: "var(--color-cobalt)" }}>.</span>
      </Link>
      
      <ul className="nav-links">
        <li><a href="#features">Features</a></li>
        <li><a href="#pricing">Pricing</a></li>
        <li><a href="#security">Security</a></li>
      </ul>
      
      <div className="nav-actions">
        <div className="region-selector" title="South Africa (ZAR)">
          <span className="flag-badge">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="100%" height="100%">
              <rect width="60" height="40" fill="#002395"/>
              <rect width="60" height="20" fill="#E23D28"/>
              <path stroke="#FFFFFF" strokeWidth="13.3" fill="none" d="M0 0l30 20L0 40h60V0z"/>
              <path stroke="#007C3C" strokeWidth="8" fill="none" d="M0 0l30 20L0 40h60V0z"/>
              <path stroke="#FCB514" strokeWidth="6.7" fill="none" d="M0 0l20 13.3L0 26.7z"/>
              <path d="M0 0l15 10L0 20z" fill="#000000"/>
            </svg>
          </span>
          <span>ZA</span>
        </div>
        <Link to="/signup" className="nav-btn-cta">
          Get Started
        </Link>
      </div>
    </nav>
  );
}
