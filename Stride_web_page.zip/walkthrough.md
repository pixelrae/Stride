# STRIDE — Team Walkthrough & Setup Guide

Welcome to the STRIDE Open Payments platform. This guide is designed to help you set up, run, and debug the application across different viewports (like testing on mobile devices) and covers advanced networking concepts that are common pitfalls in web development.

---

## 1. Stride Architecture: How it Works

STRIDE does not process payments directly. Instead, it orchestrates transactions between wallet providers using the **Open Payments** standard (https://openpayments.dev).

```
[ Payer Browser ] ───(React App)───> [ STRIDE Backend ]
      │                                    │
      │ (Redirect Consent)                 │ (Request Quote & Grant)
      ▼                                    ▼
[ Payer Wallet Provider ] <───────────> [ Payee Wallet Provider ]
```

* **Incoming Payment:** The receiver (payee) generates a request. STRIDE creates an "Incoming Payment" resource on the payee's wallet provider.
* **Quote & Grant:** When the payer (sender) wants to pay, the STRIDE backend requests a "Quote" (transaction fee/amount estimate) and a "Grant" (approval request) from the payer's wallet provider.
* **Interactive Approval:** The payer's wallet provider requires the user's consent. The browser is redirected to the provider's login/consent screen (similar to OAuth).
* **Callback & Settlement:** After the user approves, the wallet provider redirects the browser back to STRIDE's callback endpoint. STRIDE continues the grant, acquires the final access token, and executes the outgoing payment.

---

## 2. Environment Configuration (`.env`)

STRIDE uses environment variables to coordinate redirects and API endpoints.

### Backend (`backend/.env`)
Create this file in the `backend/` folder.
```env
# Credentials obtained from https://wallet.interledger-test.dev
WALLET_ADDRESS_URL=https://ilp.interledger-test.dev/your-test-wallet-id
KEY_ID=your-key-uuid-here
PRIVATE_KEY_PATH=./private.key

PORT=4000

# Where the backend redirects the user's browser after a successful callback
PUBLIC_BASE_URL=http://localhost:5173

# Registered callback endpoint (must match the URI registered with your client key)
REDIRECT_URI=http://localhost:4000/api/payments/callback
```

### Frontend (`frontend/.env`)
Create this file in the `frontend/` folder.
```env
# API URL of the backend. Note the "VITE_" prefix, which allows Vite to inline it.
VITE_API_BASE_URL=http://localhost:4000
```

---

## 3. Installation & Running

1. **Install dependencies:**
   Run in both the `backend/` and `frontend/` directories:
   ```bash
   npm install
   ```

2. **Place Private Key:**
   Download the `private.key` from your Interledger Test Wallet settings and place it in the `backend/` directory.

3. **Run the Backend:**
   ```bash
   cd backend
   npm run dev
   ```
   *(Server starts on port 4000)*

4. **Run the Frontend:**
   ```bash
   cd frontend
   npm run dev -- --host
   ```
   *(Vite starts on port 5173 or 5174. The `--host` flag allows devices on your local network to connect).*

---

## 4. Mobile Testing & Networking (Important Student Gotchas)

### ⚠️ The "Localhost" Trap
When testing the site on your phone's browser, any JavaScript request to `localhost:4000` will attempt to connect to the **phone itself**, resulting in `ERR_CONNECTION_REFUSED`. 

To test on your phone, you must choose one of the following networking options:

---

### Option A: USB Port Forwarding (Easiest & Safest)
By forwarding ports over USB, your phone behaves as if it is running the servers locally. **You do not need to change any `.env` files.**

1. Connect your phone to your PC via USB.
2. Enable **USB Debugging** in your phone's Developer Options.
3. Open Google Chrome on your computer and navigate to `chrome://inspect`.
4. Click **Port forwarding...** and configure:
   * Port `5173` $\rightarrow$ `localhost:5173`
   * Port `4000` $\dots$ `localhost:4000`
5. Check **Enable port forwarding** and click **Done**.
6. Access the site on your phone by navigating directly to `http://localhost:5173`.

---

### Option B: Tailscale or Wi-Fi LAN
If you want to access the site wirelessly via Tailscale or local Wi-Fi, you must rewrite the hostnames.

1. **Find your LAN/Tailscale IP:**
   * Linux/macOS: Run `ip route` or `ifconfig`
   * Windows: Run `ipconfig`
   * Tailscale: Run `tailscale ip -4` (e.g. `100.115.20.30`)
2. **Update Frontend env (`frontend/.env`):**
   ```env
   VITE_API_BASE_URL=http://<YOUR_IP>:4000
   ```
3. **Update Backend env (`backend/.env`):**
   ```env
   PUBLIC_BASE_URL=http://<YOUR_IP>:5173
   REDIRECT_URI=http://<YOUR_IP>:4000/api/payments/callback
   ```
4. **Vite Cache Gotcha:** Vite caches environment variables at startup. **You MUST stop and restart the frontend dev server** (`npm run dev`) for changes in `.env` to take effect.
5. **Clear Browser Cache:** Mobile browsers aggressively cache JavaScript. Open the site in an **Incognito / Private window** on your phone to ensure it uses the updated IP address.

---

### Option C: WSL2 Port Proxying
If your development servers are running inside **WSL2** (Linux) and you are attempting to connect from a phone via Windows LAN or Tailscale:
WSL2 runs in its own virtual network. Windows does not automatically forward incoming traffic from external interfaces (like Tailscale) to WSL2.

To fix this, run these port-forwarding commands in Windows PowerShell (Administrator) to proxy traffic from your Windows Tailscale/LAN IP to the WSL2 virtual machine:

1. Find the WSL2 internal IP by running `hostname -I` in your Linux terminal (e.g. `172.20.15.5`).
2. Run in PowerShell (Admin):
   ```powershell
   # Forward Backend port
   netsh interface portproxy add v4tov4 listenport=4000 listenaddress=<YOUR_LAN_OR_TAILSCALE_IP> connectport=4000 connectaddress=<WSL_INTERNAL_IP>
   
   # Forward Frontend port
   netsh interface portproxy add v4tov4 listenport=5173 listenaddress=<YOUR_LAN_OR_TAILSCALE_IP> connectport=5173 connectaddress=<WSL_INTERNAL_IP>
   ```
3. To clean up / delete these proxies later:
   ```powershell
   netsh interface portproxy reset
   ```
