# STRIDE — Interledger Open Payments App

A full-stack app (Node/Express + React/Vite) that lets users sign up with an
email + Interledger wallet address, send/receive real money over the internet
via the Open Payments protocol, and track spending/receiving history.

## How it works

This uses the **Open Payments** standard (https://openpayments.dev), not a
custom payment backend. Wallets are hosted by a wallet provider — for
development we use the free Interledger Test Wallet
(https://wallet.interledger-test.dev). Your app never touches money directly;
it just orchestrates grants/payments between wallet providers.

Flow for sending money:
1. Your app requests a grant from the receiver's wallet to create an "incoming payment"
2. Your app creates a quote on the sender's wallet (how much it'll cost/take)
3. Your app requests a grant for an "outgoing payment" — the wallet provider
   requires the user to **interactively approve** this (redirect to their wallet,
   like an OAuth consent screen)
4. After approval, the wallet redirects back to your app's `REDIRECT_URI`
5. Your app finalizes the grant and executes the outgoing payment

This interactive redirect is why **this cannot run on localhost** — the wallet
provider needs a real HTTPS URL to send the user back to.

## 1. Get test wallet credentials

1. Go to https://wallet.interledger-test.dev and create an account
2. Create a wallet address (e.g. `https://ilp.interledger-test.dev/yourname`)
3. In wallet settings, generate a **Client Key** — download `private.key`
   and copy the **Key ID** shown
4. Put `private.key` inside `backend/` and fill in `backend/.env` (copy from `.env.example`)

## 2. Local development (still works for everything except the final
   redirect approval step, which needs a public URL)

```bash
cd backend
npm install
cp .env.example .env   # fill in your values
npm run dev
```

```bash
cd frontend
npm install
echo "VITE_API_BASE_URL=http://localhost:4000" > .env
npm run dev
```

## 3. Deploying so it works over the real internet

You need a public HTTPS domain for the backend (because `REDIRECT_URI` must
be a real internet-reachable URL). Recommended: **Render.com**

### Backend on Render
1. Push this repo to GitHub
2. Render → New Web Service → point at `backend/`
3. Build command: `npm install` | Start command: `npm start`
4. Add environment variables from your `.env` (paste private key contents
   into a `PRIVATE_KEY` env var instead of a file — see note below)
5. Render gives you a URL like `https://stride-backend.onrender.com`
6. Set `PUBLIC_BASE_URL` and `REDIRECT_URI` env vars to use that domain

**Note on the private key file on Render:** disk storage isn't persistent
across deploys on the free tier. Easiest fix — change `opClient.js` to read
the key from an env var instead of a file:
```js
privateKey: Buffer.from(process.env.PRIVATE_KEY_BASE64, "base64"),
```
and set `PRIVATE_KEY_BASE64` to `base64 -i private.key` output.

### Frontend on Render (Static Site) or Vercel/Netlify
1. New Static Site → point at `frontend/`
2. Build command: `npm run build` | Publish directory: `dist`
3. Set `VITE_API_BASE_URL` to your backend's Render URL

### Final step
Update `backend/.env` → `REDIRECT_URI=https://your-backend.onrender.com/api/payments/callback`
and `PUBLIC_BASE_URL=https://your-frontend.onrender.com` (so the callback
route can redirect the user back into your React app's success page).

## Project structure

```
backend/
  server.js              entry point
  src/lib/db.js           SQLite schema (users, transactions, pending_grants)
  src/lib/opClient.js     authenticated Open Payments client
  src/routes/auth.js      signup / get user
  src/routes/payments.js  send/receive payment flow (the core logic)
  src/routes/transactions.js  history + spend/receive summary

frontend/
  src/pages/Signup.jsx     create account
  src/pages/Dashboard.jsx  send, receive, history, totals
  src/pages/PaymentSuccess.jsx
  src/lib/api.js           backend API calls
```

## Things to harden before production

- Add real auth (sessions/JWT) — signup currently has no password/login step
- Move `PRIVATE_KEY` handling to a secrets manager
- Add idempotency keys / webhook verification for incoming payments
  (right now "received" transactions are logged optimistically when a
  payment request is created, not when money actually arrives — for a
  production app you'd subscribe to the wallet's webhook/event subscription
  for incoming payment completion and update status then)
- Add input validation, rate limiting, HTTPS-only cookies, CORS allowlist
